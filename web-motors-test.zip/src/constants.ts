const raio = [
  { value: 100, Name: '100km' },
  { value: 200, Name: '200km' },
  { value: 300, Name: '300km' },
  { value: 400, Name: '400km' },
  { value: 500, Name: '500km' }
];

const states = [
  { value: 'SP', Name: 'São Paulo' },
  { value: 'ES', Name: 'Espirito Santo' },
  { value: 'BH', Name: 'Bahia' },
  { value: 'RJ', Name: 'Rio de Janeiro' },
  { value: 'DF', Name: 'Distrito Federal' },
  { value: 'MG', Name: 'Minas Gerais' }
];

export { raio, states };
