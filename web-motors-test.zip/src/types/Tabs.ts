export enum Tabs {
  car,
  motocycle
}
